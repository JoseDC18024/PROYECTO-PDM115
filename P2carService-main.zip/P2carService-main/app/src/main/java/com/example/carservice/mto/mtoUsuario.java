package com.example.carservice.mto;

public class mtoUsuario {
    private String usuario, contra;

    public mtoUsuario(String usuario, String contra) {
        this.usuario = usuario;
        this.contra = contra;
    }

    public mtoUsuario() {
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContra() {
        return contra;
    }

    public void setContra(String contra) {
        this.contra = contra;
    }
}
